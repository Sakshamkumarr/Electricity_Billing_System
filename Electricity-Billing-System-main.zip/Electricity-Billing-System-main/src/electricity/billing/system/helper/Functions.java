package electricity.billing.system.helper;

public class Functions {

	public Functions() {
		// TODO Auto-generated constructor stub
	}

}
